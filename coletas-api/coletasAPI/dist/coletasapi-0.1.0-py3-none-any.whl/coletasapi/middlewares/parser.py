from bs4 import BeautifulSoup

async def tjal_primeira_instancia_parser(ctx):
    contexto = BeautifulSoup(ctx.content, 'html.parser')

    print(contexto)