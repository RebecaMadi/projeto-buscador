import requests
from .midlewares import parser

#URL do TJAL para consultar processos de primeira instância
url_tjal_primeira = "https://www2.tjal.jus.br/cpopg/show.do"

async def search_tjal_primeira_instancia(numero_processo):
    #função de requisição de processos de primeira instancia para o TJAL 
    query_string = {
        "processo.numero": numero_processo
    }

    response = requests.get(
        url=url_tjal_primeira,
        params=query_string
    )

    if response.status_code == 200:
        success = True
        response = tjal_primeira_instancia_parser(response)
    else:
        return False
        #adicionar error handler
        #sugestão: site dos gatos para ver erros mais comuns
    
search_tjal_primeira_instancia("0710802-55.2018.8.02.0001")